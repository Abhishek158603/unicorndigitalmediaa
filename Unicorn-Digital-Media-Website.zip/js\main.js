/**
 * UNICORN DIGITAL MEDIA - Main Interactive Script
 * High-performance agency frontend logic
 */

const UNICORN_CONFIG = {
  businessName: "Unicorn Digital Media",
  founder: "Mr. Karan Sahani",
  whatsappNumber: "919455069464", // Mobile: 9455069464
  supportEmail: "karansahani9455@gmail.com",
  phone: "+91 94550 69464",
  instagram: "https://instagram.com",
};

// Initialize Lucide Icons if available
document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    window.lucide.createIcons();
  }
  initCounters();
  initPortfolioFilter();
  initContactForms();
  initServiceModal();
  initQuoteCalculator();
  initMobileMenu();
});

// Toast notification helper
function showToast(message, icon = 'check-circle') {
  let toast = document.getElementById('toastNotice');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toastNotice';
    toast.className = 'toast-notice';
    document.body.appendChild(toast);
  }
  
  toast.innerHTML = `<i data-lucide="${icon}" class="w-5 h-5 text-emerald-400"></i> <span>${message}</span>`;
  if (window.lucide) window.lucide.createIcons();
  
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3500);
}

// WhatsApp redirect builder - Guarantees direct opening of WhatsApp
function sendWhatsAppMessage(text) {
  const encodedText = encodeURIComponent(text);
  const url = `https://wa.me/${UNICORN_CONFIG.whatsappNumber}?text=${encodedText}`;
  const win = window.open(url, '_blank');
  if (!win || win.closed || typeof win.closed === 'undefined') {
    window.location.href = url;
  }
}

// Trigger inquiry for a specific service
function openServiceInquiry(serviceTitle) {
  const modal = document.getElementById('serviceModal');
  const serviceInput = document.getElementById('modalServiceInput');
  const modalHeading = document.getElementById('modalHeading');
  
  if (serviceInput && modalHeading) {
    serviceInput.value = serviceTitle;
    modalHeading.textContent = `Get Quote: ${serviceTitle}`;
  }
  
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeServiceModal() {
  const modal = document.getElementById('serviceModal');
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }
}

// Setup Service Modal
function initServiceModal() {
  const modal = document.getElementById('serviceModal');
  if (!modal) return;

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeServiceModal();
    }
  });

  const modalForm = document.getElementById('serviceInquiryForm');
  if (modalForm) {
    modalForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('modalNameInput').value.trim();
      const phone = document.getElementById('modalPhoneInput').value.trim();
      const service = document.getElementById('modalServiceInput').value.trim();
      const notes = document.getElementById('modalNotesInput').value.trim();

      const message = `👋 Hello *${UNICORN_CONFIG.businessName}*,\n\nI want to inquire about: *${service}*\n\n👤 *Name:* ${name}\n📞 *Phone:* ${phone}\n📝 *Requirement:* ${notes || 'Standard enquiry'}\n\nPlease share quotation, portfolio samples and pricing packages.`;
      
      closeServiceModal();
      showToast('Opening WhatsApp with your request...');
      setTimeout(() => {
        sendWhatsAppMessage(message);
      }, 500);
    });
  }
}

// Direct quick contact form
function initContactForms() {
  const quickForm = document.getElementById('mainContactForm');
  if (!quickForm) return;

  quickForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('contactName').value.trim();
    const phone = document.getElementById('contactPhone').value.trim();
    const service = document.getElementById('contactService').value;
    const messageText = document.getElementById('contactMessage').value.trim();

    const fullMessage = `🔥 *NEW PROJECT ENQUIRY*\n━━━━━━━━━━━━━━━━━\n🏢 *To:* ${UNICORN_CONFIG.businessName}\n👤 *Name:* ${name}\n📱 *Contact:* ${phone}\n🎯 *Service Required:* ${service}\n💬 *Project Brief:* ${messageText || 'Please contact me for details.'}`;

    showToast('Redirecting to WhatsApp for instant reply...');
    setTimeout(() => {
      sendWhatsAppMessage(fullMessage);
    }, 500);
  });
}

// Portfolio Category Filter
function initPortfolioFilter() {
  const buttons = document.querySelectorAll('.tab-btn');
  const items = document.querySelectorAll('.portfolio-item');

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');

      items.forEach(item => {
        if (filter === 'all' || item.getAttribute('data-category') === filter) {
          item.style.display = 'block';
          item.classList.add('animate-fadeIn');
        } else {
          item.style.display = 'none';
        }
      });
    });
  });
}

// Quote Estimator Calculator
function initQuoteCalculator() {
  const calcForm = document.getElementById('quoteCalculatorForm');
  if (!calcForm) return;

  const checkboxes = calcForm.querySelectorAll('.calc-checkbox');
  const speedSelect = document.getElementById('calcSpeed');
  const estimateDisplay = document.getElementById('calcEstimateResult');

  function updateEstimate() {
    let base = 0;
    let selectedServices = [];

    checkboxes.forEach(cb => {
      if (cb.checked) {
        base += parseInt(cb.getAttribute('data-price') || '0', 10);
        selectedServices.push(cb.getAttribute('data-name'));
      }
    });

    const speedMultiplier = parseFloat(speedSelect ? speedSelect.value : '1');
    const total = Math.round(base * speedMultiplier);

    if (estimateDisplay) {
      if (selectedServices.length === 0) {
        estimateDisplay.textContent = '₹0 (Select Services)';
      } else {
        estimateDisplay.textContent = `Approx ₹${total.toLocaleString('en-IN')}*`;
      }
    }

    return { total, selectedServices };
  }

  checkboxes.forEach(cb => cb.addEventListener('change', updateEstimate));
  if (speedSelect) speedSelect.addEventListener('change', updateEstimate);

  calcForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const { total, selectedServices } = updateEstimate();

    if (selectedServices.length === 0) {
      alert('Please select at least one service to get an estimate.');
      return;
    }

    const clientName = document.getElementById('calcClientName')?.value.trim() || 'Valued Client';
    const msg = `⚡ *CUSTOM PACKAGE ESTIMATE ENQUIRY*\n━━━━━━━━━━━━━━━━━\n🏢 *Agency:* ${UNICORN_CONFIG.businessName}\n👤 *Client:* ${clientName}\n🛠️ *Selected Services:*\n${selectedServices.map(s => '• ' + s).join('\n')}\n\n💰 *Estimated Plan:* ~₹${total.toLocaleString('en-IN')}\n\nPlease verify this package and provide available start dates!`;

    sendWhatsAppMessage(msg);
  });
}

// Animated Numerical Counters
function initCounters() {
  const counters = document.querySelectorAll('.counter-val');
  let animated = false;

  function runCounters() {
    if (animated) return;
    const statsSection = document.getElementById('statsSection');
    if (!statsSection) return;

    const rect = statsSection.getBoundingClientRect();
    if (rect.top <= window.innerHeight * 0.85) {
      animated = true;
      counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const suffix = counter.getAttribute('data-suffix') || '';
        let count = 0;
        const speed = target / 50;

        const update = () => {
          count += speed;
          if (count < target) {
            counter.innerText = Math.ceil(count).toLocaleString('en-IN') + suffix;
            requestAnimationFrame(update);
          } else {
            counter.innerText = target.toLocaleString('en-IN') + suffix;
          }
        };
        update();
      });
    }
  }

  window.addEventListener('scroll', runCounters);
  runCounters();
}

// Mobile Menu Drawer
function initMobileMenu() {
  const toggleBtn = document.getElementById('mobileMenuToggle');
  const closeBtn = document.getElementById('mobileMenuClose');
  const drawer = document.getElementById('mobileDrawer');
  const navLinks = document.querySelectorAll('.mobile-nav-link');

  if (toggleBtn && drawer) {
    toggleBtn.addEventListener('click', () => {
      drawer.classList.remove('hidden');
      drawer.classList.add('flex');
    });
  }

  function closeDrawer() {
    if (drawer) {
      drawer.classList.add('hidden');
      drawer.classList.remove('flex');
    }
  }

  if (closeBtn) closeBtn.addEventListener('click', closeDrawer);
  navLinks.forEach(link => link.addEventListener('click', closeDrawer));
}

// Global helper for opening direct WhatsApp
function directWhatsAppInquiry(defaultTopic = "General Services") {
  const text = `Hello *${UNICORN_CONFIG.businessName}*! 👋\nI am interested in your *${defaultTopic}*. Please share pricing, packages, and sample works.`;
  sendWhatsAppMessage(text);
}
